package com.raisin.assignment.Enum;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

public enum SourceStatus {
	
	@JsonProperty("ok")
	OK("ok"),
	@JsonProperty("done")
	DONE("done");
	
	@Getter @Setter
	private String status;
	
	SourceStatus(String status){
		this.status = status;
	}
}
