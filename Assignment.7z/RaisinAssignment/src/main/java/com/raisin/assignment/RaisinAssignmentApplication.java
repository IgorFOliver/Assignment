package com.raisin.assignment;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

import com.raisin.assignment.Enum.Kind;
import com.raisin.assignment.Enum.SourceStatus;
import com.raisin.assignment.dto.ResponseDTO;
import com.raisin.assignment.dto.SourceA;
import com.raisin.assignment.dto.SourceB;

@SpringBootApplication
public class RaisinAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(RaisinAssignmentApplication.class, args);
		RestTemplate restTemplate = new RestTemplate();
	
		SourceA sourceA = restTemplate.getForObject("http://localhost:7299/source/a", SourceA.class);
		List<SourceA> sourceAList = new ArrayList<>();
		sourceAList.add(sourceA);
		List<SourceB> sourceBList = new ArrayList<>();
		while(!SourceStatus.DONE.equals(sourceA.getStatus())){
			try {
				SourceB sourceB = restTemplate.getForObject("http://localhost:7299/source/b", SourceB.class);
				//verificar se o registro B existe no A, caso sim, enviar.
				System.out.println(sourceB.getId().getValue());
				if(Objects.nonNull(sourceB) && Objects.nonNull(sourceB.getId()) && 
					sourceAList.stream().anyMatch(a -> a.getId().equals(sourceB.getId().getValue()))) {
					ResponseDTO responseDTO = new ResponseDTO(sourceB.getId().getValue(), Kind.JOINED);
					restTemplate.postForEntity("http://localhost:7299/sink/a", responseDTO, ResponseDTO.class);
				}else {
					sourceBList.add(sourceB);
					
				}
				
				sourceA = restTemplate.getForObject("http://localhost:7299/source/a", SourceA.class);
				//
				System.out.println(sourceA.getId());
				sourceAList.add(sourceA);
			} catch (Exception e) {
				System.out.println("defective");
			}
			System.out.print(sourceA);
			System.out.println(sourceA.getStatus());
		}
	}

}
