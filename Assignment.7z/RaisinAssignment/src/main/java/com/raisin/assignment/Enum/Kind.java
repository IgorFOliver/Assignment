package com.raisin.assignment.Enum;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

public enum Kind {
	
	@JsonProperty("joined")
	JOINED("joined"),
	@JsonProperty("orphaned")
	ORPHANED("orphaned");
	
	@Getter @Setter
	private String kind;
	
	Kind(String kind){
		this.kind = kind;
	}

}
