package com.raisin.assignment.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.raisin.assignment.Enum.SourceStatus;
import com.raisin.assignment.dto.SourceA;
import com.raisin.assignment.dto.SourceB;

@Service
public class AssignmentService {

	private static final List<SourceA> SOURCESA = Collections.synchronizedList(new ArrayList<>());

	private static final List<SourceB> SOURCESB = Collections.synchronizedList(new ArrayList<>());
	
	private static SourceStatus STATUS_A = SourceStatus.OK;
	
	private static SourceStatus STATUS_B = SourceStatus.OK;

	public void doProcess() {

		loadSourceA();
		loadSourceB();
		sinkSources();

	}

	
	private void sinkSources() {
		new Thread(new Runnable() {
			@Override
			public void run() {

				if(STATUS_A.equals(SourceStatus.DONE) && STATUS_B.equals(SourceStatus.DONE)) {
					List<String> idsA = SOURCESA.stream().map(SourceA::getId).collect(Collectors.toList());
					List<String> idsB = SOURCESB.stream().map(b -> b.getId().getValue()).collect(Collectors.toList());
					
				} else if(SOURCESA.size() > 100 && SOURCESB.size() > 200){
					
					
				}
			}
		
		}).start();
	
//				
	
		
	}

	private void loadSourceB() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					SourceB sourceB;
					do {
						sourceB = getSourceB().get();
						sinkOrStore(sourceB);
					} while (SourceStatus.DONE.equals(sourceB.getStatus()));
					STATUS_B = SourceStatus.DONE;
				} catch (InterruptedException | ExecutionException e) {
					e.printStackTrace();
				}
			}

		}).start();

	}

	private void sinkJoined(String id) {
		
		
	}

	private void loadSourceA() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					SourceA sourceA;

					do {
						sourceA = getSourceA().get();
						sinkOrStore(sourceA);
					} while (SourceStatus.DONE.equals(sourceA.getStatus()));
					STATUS_A = SourceStatus.DONE;
					Thread.currentThread().interrupt();
				} catch (InterruptedException | ExecutionException e) {
					e.printStackTrace();
				}
			}
		}).start();

	}

	@Async
	private CompletableFuture<SourceA> getSourceA() {
		RestTemplate restTemplate = new RestTemplate();
		SourceA sourceA = restTemplate.getForObject("http://localhost:7299/source/a", SourceA.class);
		return CompletableFuture.completedFuture(sourceA);
	}

	@Async
	private CompletableFuture<SourceB> getSourceB() {
		RestTemplate restTemplate = new RestTemplate();
		SourceB sourceB = restTemplate.getForObject("http://localhost:7299/source/b", SourceB.class);
		return CompletableFuture.completedFuture(sourceB);
	}
	
	private void sinkOrStore(final SourceB sourceB) {
		Optional<SourceA> aSource = SOURCESA.stream().filter(a -> a.getId().equals(sourceB.getId().getValue())).findFirst();
		if(aSource.isPresent()) {
			sinkJoined(aSource.get().getId());
			SOURCESA.remove(aSource.get());
		}else {
			SOURCESB.add(sourceB);
		}
		
	}
	
	private void sinkOrStore(final SourceA sourceA) {
		Optional<SourceB> bSource = SOURCESB.stream().filter(b -> b.getId().equals(sourceA.getId())).findFirst();
		if(bSource.isPresent()) {
			sinkJoined(bSource.get().getId().getValue());
			SOURCESB.remove(bSource.get());
		}else {
			SOURCESA.add(sourceA);
		}
		
	}

}
