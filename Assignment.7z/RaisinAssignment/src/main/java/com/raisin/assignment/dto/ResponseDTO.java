package com.raisin.assignment.dto;

import com.raisin.assignment.Enum.Kind;

import lombok.Getter;
import lombok.Setter;

public class ResponseDTO {
	
	@Getter @Setter
	private String id;
	
	@Getter @Setter
	private Kind kind;
	
	public ResponseDTO(String id, Kind kind) {
		this.id = id;
		this.kind = kind;
	}
	
}
