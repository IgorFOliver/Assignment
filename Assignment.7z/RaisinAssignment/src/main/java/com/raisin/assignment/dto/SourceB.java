package com.raisin.assignment.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.raisin.assignment.Enum.SourceStatus;

@XmlRootElement(name="msg")
@XmlAccessorType(XmlAccessType.FIELD)
public class SourceB {
	
	@XmlElement(name = "id")
	private Identificator id;
	
	
	public SourceStatus getStatus() {
		return status;
	}

	public void setStatus(SourceStatus status) {
		this.status = status;
	}

	private SourceStatus status;
	
	public Identificator getId() {
		return id;
	}

	public void setId(Identificator id) {
		this.id = id;
	}

	
}
