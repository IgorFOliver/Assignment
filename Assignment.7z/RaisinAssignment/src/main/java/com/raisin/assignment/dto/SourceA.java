package com.raisin.assignment.dto;

import com.raisin.assignment.Enum.SourceStatus;

import lombok.Getter;
import lombok.Setter;


public class SourceA {
	
	@Getter @Setter
	private String id;
	
	@Getter @Setter
	private SourceStatus status;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public SourceStatus getStatus() {
		return status;
	}

	public void setStatus(SourceStatus status) {
		this.status = status;
	}


	
}
